package com.javalec.function;

public class ShareVar {
	public static String DBName = "jdbc:mysql://127.0.0.1/swingproject?serverTimezone=UTC&characterEncoding=utf8&useSSL=FALSE";
	public static String DBUser = "root";
	public static String DBPass = "qwer1234";
	public static int filename = 0;
}
