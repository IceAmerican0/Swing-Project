package com.javalec.function;

public class Static {
	
public static int seqIndex;

}
